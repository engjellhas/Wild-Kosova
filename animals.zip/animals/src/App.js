import './App.css';
import React from 'react';

import Lynx from './pages/Lynx';
import Bear from './pages/Bear';
import Wolf from './pages/Wolf';
import ErrorPage from './pages/Errorpage'

import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Homepage from './pages/Homepage';





function App() {
  return (

     <> 
      {/* <NavBar/>
      <Lynx />
      <Bear />
      <Wolf/>
      <ErrorPage/> */}

      <Router>
      

        <Routes>

            <Route path='/' to element={<Homepage/>} /> 
            <Route path='/lynx' to element={<Lynx/>} /> 
            <Route path='/Bear' to element={<Bear/>} /> 
            <Route path='/Wolf' to element={<Wolf/>} /> 
            <Route path='/*' to element={<ErrorPage/>}/>

        </Routes>

        
      </Router>

     </>

  );
}

export default App;
