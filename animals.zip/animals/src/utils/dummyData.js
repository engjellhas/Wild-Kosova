
const menu = [
    {
        id: "#home",
        path: "/",
        name: "Home",
    },  
    {
        id: "#lynx",
        path: "/lynx",
        name: "Lynx",
    },  
    {
        id: "#bear",
        path: "/bear",
        name: "Bear",
    },
    {
        id: "#wold",
        path: "/wolf",
        name: "Wolf",
    },
   
];




export { menu };
