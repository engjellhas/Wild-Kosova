import React from 'react'
import NavBar from './NavBar'
import {menu} from '../utils/dummyData'
import uki from '../photos/uki.png'
import ariu from '../photos/arusha.png'
import lynx from '../photos/lynxshtrit.png'
import './Homepage.css'
import Footer from '../components/footer/Footer'
import { Link } from 'react-router-dom'

const Homepage = () => {
  return (
    <>
        <NavBar menuItems={menu}/>
        <div className="faqja">
            <h1>
                MOST COMMON WILD ANIMALS IN <br /> KOSOVO
            </h1>
            <div className="fotot">
                <Link to="/wolf" ><img src={uki} alt="" /></Link>

                <Link to="/Bear" ><img src={ariu} alt="" /></Link>

            
                <Link to="/lynx" ><img src={lynx} alt="" /></Link>

            </div>
        </div>
        <Footer/>
    </>
  )
}

export default Homepage