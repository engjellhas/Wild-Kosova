import React from 'react'
import Footer from '../components/footer/Footer'
import Home from '../components/home/Home'
import Home2 from '../components/home/Home2'
import Ariu from '../photos/arusha.png'
import BackAriu from "../photos/arushaaa.jpg"
import './Bear.css'
import NavBar from './NavBar'
import {menu} from '../utils/dummyData'



const Bear = () => {
  return (
    <div id='bear'>
        <NavBar menuItems={menu}/>
        <Home emri = "Bear"
        info="Bears are mammals that belong to the family Ursidae. They can be as small as four feet long and about
         60 pounds (the sun bear) to as big as eight feet long
         and more than a thousand pounds (the polar bear). They're found throughout North America,
          South America, Europe, and Asia." 
          />
        <Home2
        foto={Ariu}
        foto1={BackAriu}
        />
        <Footer/>

    </div>
  )
}

export default Bear