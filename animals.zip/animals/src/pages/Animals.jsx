import React from 'react'
import NavBar from '../../../../ora9/my-app/src/components/NavBar'
import Footer from '../components/footer/Footer'

function Animals() {
  return (
    <div>
        <NavBar/>
        <Footer/>
    </div>
  )
}

export default Animals