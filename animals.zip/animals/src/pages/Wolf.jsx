import React from 'react'
import Footer from '../components/footer/Footer'
import Home from '../components/home/Home'
import Home2 from '../components/home/Home2'
import ujki from '../photos/ujku.jpg'
import uki from '../photos/uki.png'
import NavBar from './NavBar'
import {menu} from '../utils/dummyData'


import './Wolf.css'



const Wolf = () => {
  return (
    <div id='Wolf'>
        <NavBar menuItems={menu}/>
        <Home emri = "Wolf"
        info="Wolves are complex, highly intelligent animals who are caring, playful, and above all devoted to family. 
        Only a select few other species exhibit these traits so clearly.
         Just like elephants, gorillas and dolphins, wolves educate their young, take care of their injured and live in family groups." 
          />
        <Home2
        foto={uki}
        foto1={ujki}
        />
        <Footer/>

    </div>
  )
}

export default Wolf