import React from 'react'
import Footer from '../components/footer/Footer';
import Home from '../components/home/Home'
import Home2 from '../components/home/Home2';
import lyx2 from '../photos/lynxshtrit.png'
import lyx from '../photos/lyx2.jpg'
import NavBar from './NavBar';
import {menu} from '../utils/dummyData'




function Lynx  ()  {
  return (
    <div>
    <NavBar menuItems={menu} />
    <Home 
    emri='Lynx'
    info='The lynx is a solitary cat that haunts the remote northern forests of North America, Europe,
    Their large paws are also furry and hit the ground with a spreading toe motion that makes them function as natural snowshoes.' />
    <Home2
    foto1={lyx}
    foto={lyx2}
    />
    <Footer/>
    </div>
  )
}

export default Lynx