import React from 'react'
import { NavLink } from 'react-router-dom'
import './NavBar.css'



const NavBar = (props) => {

    const { menuItems } = props;


  return (
    <div className='sum'>
        <div className="logo">
            WILD KOSOVA.
        </div>

        <nav className="item">
            <ul className='ul'>
            {menuItems.map((el) => (
                        <li key={el.id}>
                            <NavLink to={el.path}>{el.name}</NavLink>
                        </li>
                    ))}

            </ul>
        </nav>
        



     </div>
  );
};

export default NavBar