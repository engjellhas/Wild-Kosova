import React from 'react'
import { Link } from 'react-router-dom'

function ErrorPage() {
  return (
    <div className="error-page">
        <div>
            <p>
                OOPS.. 
                <br />
                Error page
            </p>
            <Link to="/">Back to home!</Link>
        </div>
    </div>
  )
}

export default ErrorPage