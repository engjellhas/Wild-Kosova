const menu = [
    {
        id: "#header",
        path: "/",
        name: "Home",
    },  
    {
        id: "#wolf",
        path: "/wolf",
        name: "Wolf",
    },
    {
        id: "#lynx",
        path: "/lynx",
        name: "Lynx",
    },
    {
        id: "#bear",
        path: "/bear",
        name: "Bear",
    }
];
export { menu };
