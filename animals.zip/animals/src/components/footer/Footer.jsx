import React from 'react'

const Footer = () => {
  return (
    <div className='footer'>All rights reserved @Wild-Kosovo. 2022</div>
  )
}

export default Footer