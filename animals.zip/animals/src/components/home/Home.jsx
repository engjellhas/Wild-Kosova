import React from 'react'
import './Home.css'

// import { menu } from "../../dummyData";
// import Navbar from '../../components/navbar/Navbar';





const home = (props) => {
  return (
   <>
        {/* <Navbar menuItems={menu} /> */}


         <div className='home' style={ {background:'"../../photos/pexels-janko-ferlic-1068554.jpg"'} }>
            <h1>{props.emri}</h1>
            <div className='glass'>
            <h2>About</h2>
            <p>{props.info}</p>
            </div>

                <input type="button" className='button' value="More..." />
        </div>
       
   
   </>
  )
}

export default home