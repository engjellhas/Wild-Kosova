import React from 'react'

const Home2 = (props) => {
  return (
    <div className="home2">

            <img className='maca' src={props.foto1} alt="as" />

            <div className='rendi'>
            <h1>Quick Facts </h1>
            <ul><li>
                    Type: Mammal.
                </li>
                <li>
                    Diet: Carnivore.
                </li>
                <li>
                    Lifespan: Up to 17 years.

                </li>
                <li>
                Size: Head and body 80-130 cm; tail of around 16-23 cm 
                </li>
            </ul>         
            <img className='maca' src={props.foto} alt="as" />

            </div>
        </div>
  )
}

export default Home2